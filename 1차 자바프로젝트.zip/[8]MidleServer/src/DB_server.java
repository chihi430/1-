import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DB_server {
	static {
		try {
			Class.forName("orcle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException cnfe) {
			// cnfe.printStackTrace();
		}
	}
	Socket socket;
	Connection con = null;
//   String id;
//   String name;
//   String password;

	String check_login = "select * from pmember where pid=? and passwd=?";
	String check_ID = "select * from pmember where pid = ?";
	String insert_member = "insert into pmember values(?,?,?,'0','0')";
	String blacklist_member = "update pmember set blacklist = '1' where blacklist='0' and pid=?";
	String blacklistOff_member = "update pmember set blacklist = '0' where blacklist='1' and pid=?";
	String blacklist_listmember = "select * from pmember where blacklist = '1'";

	public DB_server() {
		connectdatabase();
	}

	// 디비 연결
	public void connectdatabase() {
		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// id 중복확인 디비
	public boolean checkID(String id) {
		// connectdatabase();
		PreparedStatement pstmt1 = null;
		ResultSet rs;
		// 중복체크
		String sql = check_ID;
		try {
			pstmt1 = con.prepareStatement(sql);
			// pstmt1 = con.prepareStatement(sql);
			pstmt1.setString(1, id);
			rs = pstmt1.executeQuery();

			// 중복된 쿼리값 가져와서 비교
			if (rs.next()) {
				if (rs.getString(1).equals(id)) {
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// 회원가입 db
	public void joinDB(String id, String password, String name) {
		// connectdatabase();
		String sql = insert_member;

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, password);
			pstmt.setString(3, name);
			int updateCount = pstmt.executeUpdate();
			System.out.println("데이터 베이스 입력되었습니다.");
		} catch (Exception e) {
			System.out.println("데이터 베이스 입력오류!.");
		}
	}

	// 로그인 db
	public boolean loginDB(String id, String password, Socket socket) {
		// connectdatabase();

		String sql = check_login;
		PrintWriter out = null;

		try {
			out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);

			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				if (rs.getString(5).equals("1")) {
					out.println("해당 아이디는 블랙리스트입니다.");
					out.println("이용이 불가능 합니다 관리자에게 문의해주세요");
					return false;
				}
				if (rs.getString(1).equals(id) && rs.getString(2).equals(password) && rs.getString(5).equals("0")) {
					System.out.println(id + "님 접속완료");
					System.out.println("디비 커넥트완료");
					return true;
				} else {
					System.out.println("아이디 비밀번호가 틀립니다.");
					return false;
				}
			} else {
				System.out.println("아이디와 비밀번호를 입력해 주세요.");
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("알수 없는 에러가 발생했습니다.");
		}
		return false;
	}

	public boolean blacklistRegistMember(String id) {

		String sql = blacklist_member;
		PreparedStatement pstmt = null;
		ResultSet rs;
		// 블랙리스트 회원등록

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			// 중복된 쿼리값 가져와서 비교

			// System.out.println(rs.getString(0).toString());
			// System.out.println(rs.getString(1).toString());
/*			
 			if (rs.getString(1).equals(id)) {
				System.out.println("쿼리값 확인");
				return false;
			} else {
				System.out.println("DB 블랙리스트 RS.NEXT 에러");
				return true;
			}
*/
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean blacklistOffMember(String id) {

		PreparedStatement pstmt = null;
		ResultSet rs;
		// 블랙리스트 회원등록
		String sql = blacklistOff_member;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			// 중복된 쿼리값 가져와서 비교

			if (rs.getString(1).equals(id)) {
				System.out.println("쿼리값 확인");
				return false;
			} else {
				System.out.println("DB 블랙리스트 RS.NEXT 에러");
				return true;
			}

		} catch (SQLException esql) {
			esql.printStackTrace();
		}
		return true;
	}

	public void blacklistMember() {

		PreparedStatement pstmt = null;
		ResultSet rs;
		// 블랙리스트 회원등록
		String sql = blacklistOff_member;

		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			// 중복된 쿼리값 가져와서 비교
			while (rs.next()) {
				System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
				System.out.println(rs.getString(4));
				System.out.println(rs.getString(5));
			}
		} catch (SQLException esql) {
			esql.printStackTrace();
		}
	}
}